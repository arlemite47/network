'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowUpRight, ChevronRight, Disc3, ExternalLink, ContactRound, Mail, Menu, Play, Send, Sparkles, X } from 'lucide-react'

type Section = 'home' | 'projects' | 'about' | 'contact'

const projects = [
  { number: '01', name: 'Pulse VPN', status: 'LIVE', description: 'Мой личный VPN — тихий инструмент для свободного доступа и приватности.', tags: ['Network', 'Privacy'], href: 'https://t.me/mitevpnbot', cta: 'Открыть бота' },
  { number: '02', name: 'Pulse AI', status: 'IN BUILD', description: 'Идея, которая постепенно становится продуктом. Подробности появятся, когда будет что показать.', tags: ['AI', 'Product'], href: '#contact', cta: 'Узнать первым' },
]

const contacts = [
  { label: 'Email', value: 'arleprime@proton.me', href: 'mailto:arleprime@proton.me', icon: Mail },
  { label: 'Telegram', value: '@arlemitek', href: 'https://t.me/arlemitek', icon: Send },
  { label: 'Discord', value: '@arlemite.net', href: 'https://discord.com/users/arlemite.net', icon: ContactRound },
  { label: 'TikTok', value: '@arlemite.net', href: 'https://tiktok.com/@arlemite.net', icon: Sparkles },
]

export function PortfolioSite({ initialSection = 'home' }: { initialSection?: Section }) {
  const [section, setSection] = useState<Section>(initialSection)
  const [menuOpen, setMenuOpen] = useState(false)
  const [playing, setPlaying] = useState(false)
  const [lagMode, setLagMode] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    if (!audioRef.current) return
    if (playing) audioRef.current.play().catch(() => setPlaying(false))
    else audioRef.current.pause()
  }, [playing])

  useEffect(() => {
    if (sessionStorage.getItem('arlemite-lag-seen')) return
    const delay = window.setTimeout(() => {
      sessionStorage.setItem('arlemite-lag-seen', '1')
      setLagMode(true)
      window.setTimeout(() => setLagMode(false), 3000)
    }, 11000)
    return () => window.clearTimeout(delay)
  }, [])

  const navigate = (next: Section) => {
    setSection(next)
    setMenuOpen(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <main className={`site-shell min-h-screen overflow-hidden bg-[#050505] text-[#f4f1eb] selection:bg-[#ff3b30] selection:text-white ${lagMode ? 'lag-mode' : ''}`}>
      {lagMode && <div className="lag-overlay" role="status" aria-live="polite">Something will happen soon</div>}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true"><div className="ambient-glow ambient-glow-one" /><div className="ambient-glow ambient-glow-two" /><div className="ambient-noise" /></div>
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-white/[0.08] bg-[#09090a]/75 px-5 py-4 backdrop-blur-xl md:px-10">
        <button onClick={() => navigate('home')} className="group flex items-center gap-3 text-left" aria-label="Arlemite — главная">
          <span className="relative flex size-9 items-center justify-center overflow-hidden rounded-full bg-[#ff3b30] font-mono text-sm font-bold text-white ring-1 ring-white/20"><span>a/</span><img src="/icon/arlemite.png" alt="Arlemite" className="absolute inset-0 size-full object-cover" onError={(event) => { event.currentTarget.style.display = 'none' }} /></span>
          <span className="font-mono text-sm tracking-tight">ARLEMITE<span className="text-[#ff3b30]">.</span>NET</span>
        </button>
        <nav className="hidden items-center gap-1 md:flex" aria-label="Основная навигация">{(['home', 'projects', 'about', 'contact'] as Section[]).map((item) => <NavButton key={item} item={item} current={section} onClick={navigate} />)}</nav>
        <button className="rounded-full border border-white/15 p-2 md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="Открыть меню">{menuOpen ? <X /> : <Menu />}</button>
        {menuOpen && <nav className="absolute right-5 top-20 flex w-48 flex-col gap-2 rounded-2xl border border-white/10 bg-[#151517] p-3 shadow-2xl md:hidden">{(['home', 'projects', 'about', 'contact'] as Section[]).map((item) => <NavButton key={item} item={item} current={section} onClick={navigate} />)}</nav>}
      </header>

      <div className="relative z-10 mx-auto max-w-7xl px-5 md:px-10">
        {section === 'home' && <Home navigate={navigate} />}
        {section === 'projects' && <Projects />}
        {section === 'about' && <About />}
        {section === 'contact' && <Contact />}
      </div>

      <audio ref={audioRef} src="/music/jealously.mp3" loop preload="metadata" onEnded={() => setPlaying(false)} />
      <div className="fixed bottom-5 left-1/2 z-30 flex w-[calc(100%-2.5rem)] max-w-md -translate-x-1/2 items-center gap-3 rounded-full border border-white/15 bg-[#202023]/95 px-4 py-3 shadow-2xl backdrop-blur-xl">
        <button onClick={() => setPlaying(!playing)} className="flex size-10 shrink-0 items-center justify-center rounded-full bg-[#ff3b30] text-white transition-transform hover:scale-105" aria-label={playing ? 'Пауза' : 'Воспроизвести'}>{playing ? <span className="flex gap-1"><i className="h-4 w-1 bg-current" /><i className="h-4 w-1 bg-current" /></span> : <Play className="ml-0.5" size={16} fill="currentColor" />}</button>
        <div className="min-w-0 flex-1"><div className="flex items-center justify-between"><p className="truncate text-xs font-medium">{playing ? 'now playing / jealously' : 'your soundtrack goes here'}</p><span className="font-mono text-[10px] text-white/40">{playing ? 'playing' : '00:00'}</span></div><div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10"><div className={`h-full rounded-full bg-[#ff3b30] transition-all ${playing ? 'w-1/3 animate-pulse' : 'w-0'}`} /></div></div><Disc3 className={`hidden shrink-0 text-[#ff3b30] sm:block ${playing ? 'animate-spin' : ''}`} size={18} />
      </div>
      <footer className="relative z-10 mx-auto mt-24 flex max-w-7xl flex-col gap-3 border-t border-white/10 px-5 py-8 pb-28 text-xs text-white/40 md:flex-row md:items-center md:justify-between md:px-10"><span>© 2026 arlemite.net</span><span className="font-mono">made slowly / shared honestly</span></footer>
    </main>
  )
}

function NavButton({ item, current, onClick }: { item: Section; current: Section; onClick: (s: Section) => void }) { const labels = { home: 'Главная', projects: 'Проекты', about: 'Обо мне', contact: 'Контакты' }; return <button onClick={() => onClick(item)} className={`rounded-full px-3 py-1.5 text-sm transition-colors ${current === item ? 'bg-white/10 text-[#ff3b30]' : 'text-white/55 hover:text-white'}`}>{labels[item]}</button> }

function Home({ navigate }: { navigate: (s: Section) => void }) { return <section className="relative grid min-h-[calc(100vh-90px)] items-center gap-16 py-16 lg:grid-cols-[1.1fr_.9fr] lg:py-24"><div className="floating-phrase" aria-hidden="true">LAG / BLOOD / STATIC</div><div><div className="mb-8 flex items-center gap-3 font-mono text-xs uppercase tracking-[.25em] text-[#ff3b30]"><span className="size-2 rounded-full bg-[#ff3b30] shadow-[0_0_14px_#ff3b30]" /> a small personal archive</div><h1 className="max-w-4xl text-[clamp(4rem,10vw,9rem)] font-black leading-[.83] tracking-[-.075em]">Привет,<br /><span className="text-[#ff3b30]">я Arlemite.</span></h1><p className="mt-10 max-w-xl text-lg leading-relaxed text-white/60 md:text-xl">Мне 15, я меланхолик и человек, который больше наблюдает, чем объясняет. Люблю ночные мысли, честные разговоры, музыку под настроение и моменты, в которых можно просто быть собой.</p><p className="mt-5 max-w-xl text-sm leading-relaxed text-white/35">Родился 11 ноября 2011 года — Скорпион. Иногда пишу код, иногда строю планы, иногда ничего не делаю. Всё это тоже часть жизни.</p><div className="mt-8 flex flex-wrap gap-2 text-xs text-white/45"><span className="rounded-full border border-white/10 px-3 py-1.5">melancholic soul</span><span className="rounded-full border border-white/10 px-3 py-1.5">15 y.o.</span><span className="rounded-full border border-white/10 px-3 py-1.5">11.11.2011</span><span className="rounded-full border border-white/10 px-3 py-1.5">still becoming</span></div><div className="mt-10 flex flex-wrap gap-3"><button onClick={() => navigate('about')} className="group flex items-center gap-3 rounded-full bg-[#ff3b30] px-6 py-3 font-semibold text-white transition hover:bg-[#ff5a50]">Узнать меня <ArrowUpRight size={18} /></button><button onClick={() => navigate('projects')} className="rounded-full border border-white/15 px-6 py-3 text-sm text-white/75 transition hover:border-white/40">Посмотреть проекты</button></div></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1"><InfoCard title="сейчас" value="строю своё" detail="Маленькие проекты, большие мысли и пространство для роста." /><InfoCard title="работа" value="Gemini Helper Squad" detail="Google · экспериментирую, учусь, помогаю." /><InfoCard title="настроение" value="тихая энергия" detail="Не всегда громко — зато по-настоящему." /><button onClick={() => navigate('contact')} className="group flex items-center justify-between rounded-3xl border border-[#ff3b30]/30 bg-[#ff3b30]/[.08] p-5 text-left transition hover:bg-[#ff3b30]/[.14]"><span><span className="block font-mono text-[10px] uppercase tracking-[.2em] text-[#ff3b30]">open to</span><span className="mt-2 block text-xl font-bold">новым предложениям</span></span><ArrowUpRight className="text-[#ff3b30] transition group-hover:translate-x-1 group-hover:-translate-y-1" /></button></div></section> }

function InfoCard({ title, value, detail }: { title: string; value: string; detail: string }) { return <div className="rounded-3xl border border-white/10 bg-white/[.035] p-5 transition hover:border-white/20"><span className="font-mono text-[10px] uppercase tracking-[.2em] text-[#ff3b30]">{title}</span><h2 className="mt-2 text-2xl font-bold tracking-[-.04em]">{value}</h2><p className="mt-2 text-sm leading-relaxed text-white/40">{detail}</p></div> }

function Projects() { return <section className="min-h-[calc(100vh-90px)] py-20"><Eyebrow>selected work / 2024—26</Eyebrow><h2 className="mt-5 max-w-3xl text-6xl font-black tracking-[-.07em] md:text-8xl">Проекты, которые<br /><span className="text-[#ff3b30]">двигают вперёд.</span></h2><div className="mt-20 grid gap-5 md:grid-cols-2">{projects.map((project) => <a key={project.name} href={project.href} target={project.href.startsWith('http') ? '_blank' : undefined} rel="noreferrer" className="group flex min-h-80 flex-col justify-between rounded-[2rem] border border-white/10 bg-white/[.035] p-7 transition hover:-translate-y-1 hover:border-[#ff3b30]/50"><div className="flex justify-between"><span className="font-mono text-sm text-[#ff3b30]">{project.number}</span><span className="rounded-full border border-white/10 px-3 py-1 font-mono text-[10px] text-white/50">{project.status}</span></div><div><h3 className="text-4xl font-bold tracking-[-.05em]">{project.name}</h3><p className="mt-3 max-w-sm text-white/50">{project.description}</p><div className="mt-6 flex items-center justify-between gap-3"><div className="flex gap-2">{project.tags.map((tag) => <span key={tag} className="rounded-full bg-white/5 px-3 py-1 text-xs text-white/60">{tag}</span>)}</div><span className="flex shrink-0 items-center gap-2 text-sm text-[#ff3b30]">{project.cta}<ExternalLink size={15} className="transition group-hover:translate-x-1" /></span></div></div></a>)}</div></section> }

function About() { return <section className="min-h-[calc(100vh-90px)] py-20"><Eyebrow>the person behind the pixels</Eyebrow><div className="mt-8 grid gap-14 lg:grid-cols-[.8fr_1.2fr]"><h2 className="text-6xl font-black tracking-[-.07em] md:text-8xl">Код — это<br /><span className="text-[#ff3b30]">часть меня.</span></h2><div className="max-w-xl text-lg leading-relaxed text-white/60"><p>Я full-stack разработчик, но этот сайт не только про код. Мне интересны люди, атмосфера, свобода и то, как маленькие идеи становятся частью чьей-то жизни.</p><p className="mt-6">Увлекаюсь проектами, связанными с целями <span className="text-white">Freedom Network</span>. Сейчас работаю в <span className="text-[#ff3b30]">Google: Gemini Helper Squad</span>.</p><div className="mt-12 grid gap-3 sm:grid-cols-2"><div className="rounded-2xl border border-white/10 bg-white/[.035] p-5"><span className="font-mono text-3xl text-[#ff3b30]">15</span><p className="mt-2 text-white/45">лет, но уже в деле</p></div><div className="rounded-2xl border border-white/10 bg-white/[.035] p-5"><span className="font-mono text-3xl text-[#ff3b30]">∞</span><p className="mt-2 text-white/45">идей на потом</p></div><div className="rounded-2xl border border-white/10 bg-white/[.035] p-5 sm:col-span-2"><span className="font-mono text-xs uppercase tracking-[.2em] text-[#ff3b30]">личная заметка</span><p className="mt-3 text-white/65">Не стараюсь казаться кем-то одним. Сегодня я могу собирать продукт, а завтра — слушать одну песню по кругу и думать о жизни.</p></div></div></div></div></section> }

function Contact() { return <section className="min-h-[calc(100vh-90px)] py-20"><Eyebrow>let&apos;s make something</Eyebrow><h2 className="mt-5 max-w-4xl text-6xl font-black tracking-[-.07em] md:text-8xl">Открыт к новым<br /><span className="text-[#ff3b30]">предложениям.</span></h2><p className="mt-8 max-w-xl text-lg leading-relaxed text-white/50">Если у тебя есть идея, предложение или просто хочется поговорить — напиши. Я не обещаю мгновенный ответ, но точно прочитаю.</p><div className="mt-16 grid gap-3 md:grid-cols-2">{contacts.map(({ label, value, href, icon: Icon }) => <a key={label} href={href} target={href.startsWith('http') ? '_blank' : undefined} rel="noreferrer" className="group flex items-center justify-between rounded-2xl border border-white/10 bg-white/[.035] p-5 transition hover:border-[#ff3b30]/50"><span className="flex items-center gap-4"><span className="flex size-11 items-center justify-center rounded-full bg-white/5 text-[#ff3b30]"><Icon size={18} /></span><span><span className="block text-xs text-white/40">{label}</span><span className="text-lg">{value}</span></span></span><ChevronRight className="text-white/30 transition group-hover:translate-x-1 group-hover:text-[#ff3b30]" /></a>)}</div></section> }
function Eyebrow({ children }: { children: React.ReactNode }) { return <div className="flex items-center gap-3 font-mono text-xs uppercase tracking-[.24em] text-white/40"><span className="size-2 rounded-full bg-[#ff3b30]" />{children}</div> }

export default PortfolioSite
