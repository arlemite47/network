import PortfolioSite from '@/components/portfolio-site'

export default function AboutPage() {
  return <PortfolioSite initialSection="about" />
}
