import PortfolioSite from '@/components/portfolio-site'

export default function ContactPage() {
  return <PortfolioSite initialSection="contact" />
}
